/*
 * web_queue.h - An empty file. Use it if you wish, don't if you don't.
 * 
 */

#ifndef WEB_QUEUE_H
#define WEB_QUEUE_H 1


#endif /* WEB_QUEUE_H */



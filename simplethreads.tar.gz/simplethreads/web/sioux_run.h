#ifndef SIOUX_RUN_H
#define SIOUX_RUN_H 1

void web_runloop(const char *host, int port, const char *docroot);

#endif /* SIOUX_RUN_H */
